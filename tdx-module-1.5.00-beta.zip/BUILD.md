# How to Build
List the steps to build the binary and requirements from build environment

- [Software Requirements](#software-requirements)
- [Make targets](#make-targets)
- [Environment dependencies](#environment-dependencies)
- [Binary file date](#binary-file-date)


## Software Requirements
-	Clang 9.0.0


-	Python 3.6.3


## Environment dependencies

-	Binary padding script 


- Compiled in Linux* OS


-	[IPP 2021.7.1](https://github.com/intel/ipp-crypto/releases/tag/ippcp_2021.7.1):

  1) IPP can be automatically built by the project's makefile.

     - IPP sources needs to be placed under ./libs/ipp/ipp-crypto-ippcp_2021.7.1 folder.

     - Tools that are required to build IPP crypto lib described in the following [link](https://github.com/intel/ipp-crypto/blob/ippcp_2021.7.1/BUILD.md)

  2) It can also be built separately with the following flags:
    
```bash
	cd <PROJ_DIR>/libs/ipp/ipp-crypto-ippcp_2021.7.1/

	CC=clang CXX=clang++ cmake CMakeLists.txt -B_build -DARCH=intel64 -DMERGED_BLD:BOOL=off -DPLATFORM_LIST="y8" -DIPPCP_CUSTOM_BUILD="IPPCP_AES_ON;IPPCP_CLMUL_ON;IPPCP_VAES_ON;IPPCP_VCLMUL_ON";
	
	cd _build
	
	make -j8 ippcp_s_y8
```


## Make targets
The binary generation contains the date of the created binary.

The date and the build num can be extracted from the production binary using SEAMCALL TDH.SYS.INFO (leaf #32), and taking the values of "build\_date" and "build_num" fields.

In order to reproduce the exact binary, it is required to include the origin date, and the build number:

```bash
make RELEASE=1 TDX_MODULE_BUILD_DATE=<origin date in format YYYYMMDD> TDX_MODULE_BUILD_NUM=<build number>
```

1) Build the project: 

```bash
make RELEASE=1
```
	
2) Clean everything:
 
```bash
make clean
```

3) Clean everything including the IPP:
 
```bash
make cleanall
```
